<?php

define( "MONDAY_URL", "" );
define( "MONDAY_API_KEY", "" );

?>